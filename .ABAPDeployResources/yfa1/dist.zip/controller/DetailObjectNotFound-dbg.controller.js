sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("learninghub.learningroom.btp.flightanalysis1.controller.DetailObjectNotFound", {});
});